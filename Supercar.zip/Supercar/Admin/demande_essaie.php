<?php

session_start();
// Protection : réservé aux admins
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header('location: loginAdmin.php');
    exit();
}

include("backend/connexion.php");
include("backend/gestion_demande/FonctionDemande.php");

$pagination = isset($_GET['num']) ? (int)$_GET['num'] : 1;

$Demande_essai = Get_All_Demande($bdd);

$count = count($Demande_essai);

if ($count % 5 != 0) { 
    $nombre_pagination = ($count / 5) + 1;
} else {
    $nombre_pagination = ($count / 5);
}
$debut_voiture = ($pagination - 1) * 5;

$index = $debut_voiture;

?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Supercar - Demandes d'essai</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css">
    <link rel="stylesheet" href="assets/demande_essai.css">
    <link rel="stylesheet" href="assets/header.css">
</head>
<body>

    <?php  include("include/header.php");?>

    <main class="content">
        <header class="header-section">
            <div class="page-header-left">
                <h1><i class="bi bi-calendar-check"></i> Liste des demandes </h1>
                <p>Gérez facilement les demandes d’essai de véhicules envoyées par les visiteurs de votre site Supercar.</p>
            </div>
            <div class="filter-group">
                <span>Filtrer :</span>
                <button class="btn-filter" data-type="date">Date</button>
                <button class="btn-filter" data-type="statut">Statut</button>
            </div>
        </header>

        
        <p id= "resultat"></p>
        <div class="table-container">
            <table>
                <thead>
                    <tr>
                        <th>Modele</th>
                        <th>Date essai</th>
                        <th>Client</th>
                        <th>Statut</th>
                        <th>Modifier statut</th>
                    </tr>
                </thead>
        
        <tbody id="table-body">
        <?php for($i = 0 ; $i < 5 && $index < $count ; $i++) { ?>
        <tr>
            <td><?php echo $Demande_essai[$index]['modele']; ?></td>
            <td><?php echo $Demande_essai[$index]['daty']; ?> à <?php echo $Demande_essai[$index]['heure'] ;?>h</td>
            <td><?php echo $Demande_essai[$index]['nom']; ?></td>
            <td><?php echo $Demande_essai[$index]['stat']; ?></td>

            <td>
                <form action="backend/gestion_demande/update_statut.php" method="post" class="form-inline">

                    <input type="hidden" name="id_demande" value="<?php echo $Demande_essai[$index]['id']; ?>">

                    <div class="action-group">
                        <select name="statut" class="select-statut">
                            <option value="valider">Valider</option>
                            <option value="annuler">Annuler</option>
                            <option value="en_attente">En attente</option>
                        </select>

                        <button type="submit" class="btn-confirmer">
                            Confirmer
                        </button>
                    </div>

                </form>
            </td>

        </tr>
        <?php 
        $index++;
        } ?>
        </tbody>
        
        </table>
        </div>

        <div class = "pagination">
            <?php for($i = 1 ; $i <= $nombre_pagination ; $i++) { ?>
                        <a href = "?num=<?php echo $i; ?>"><?php echo $i; ?></a>
            <?php } ?>
        </div>
        <div class="footer-actions">
           
        </div>
    </main>

<script>
    
        document.querySelectorAll(".btn-filter").forEach(btn => {
    btn.addEventListener("click", () => {

        const valeur = btn.dataset.type;

        document.getElementById("resultat").innerText = "Chargement...";

        setTimeout(() => {
            fetch("backend/gestion_demande/traitement_Filtrage.php", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify({ type: valeur })
            })
            .then(response => response.json())
            .then(data => {
                document.getElementById("resultat").innerText = data.message;

                if (data.html) {
                    document.getElementById("table-body").innerHTML = data.html;
                }
            })
            .catch(error => {
                document.getElementById("resultat").innerText = "Erreur";
            });

        }, 500);

    });
});

</script>

</body>

</html>