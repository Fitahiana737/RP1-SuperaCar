<?php
session_start();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: catalogue.php');
    exit();
}

include 'connexion.php'; 



$id_client   = $_SESSION['id_client']   ?? 0;
$id_voiture  = (int)($_POST['id_voiture']  ?? 0);
$date_essai  = $_POST['date_essai']    ?? '';
$heure_demande = $_POST['heure_essai'] ?? 8;


if ($id_client <= 0 || $id_voiture <= 0 || empty($date_essai)) {
    $_SESSION['message'] = "Données incomplètes. Veuillez réessayer.";
    header('Location: ../demande-essai.php' . ($id_voiture > 0 ? '?id=' . $id_voiture : ''));
    exit();
}

$check = $bdd->prepare("
    SELECT id_demande 
    FROM demande_essai 
    WHERE idvoiture = ? AND id_client = ?
");

$check->bind_param("ii", $id_voiture, $id_client);
$check->execute();
$result = $check->get_result();

if ($result->num_rows > 0) {
    $_SESSION['message'] = "Vous avez déjà fait une demande d'essai pour cette voiture.";
    header("Location: ../demande-essai.php");
    exit();
}

// Insertion
$stmt = $bdd->prepare("
    INSERT INTO demande_essai 
    (date_essai, statut, idvoiture, id_client , heure_demande) 
    VALUES (?, 'en_attente', ?, ?, ?)
");

if (!$stmt) {
    die("Erreur prepare : " . $bdd->error);
}

$stmt->bind_param("siii", $date_essai, $id_voiture, $id_client , $heure_demande);

if ($stmt->execute()) {
    $_SESSION['message'] = "Votre demande d'essai a bien été enregistrée ! Nous vous contacterons rapidement.";
} else {
    $_SESSION['message'] = "Une erreur est survenue. Veuillez réessayer.";
}

header("Location: ../demande-essai.php");
exit();