<?php session_start(); 

require_once 'backend/fonctionsDetails.php';
require_once 'backend/fonctionsLogin.php';
require_once 'backend/fonctionContenu.php';

if (!isset($_SESSION['id_client'])) {
    header('Location: login.php?erreur=connexion');
    exit();
}

// Récupération des infos fraîches de la base de données
$client = getClientById($_SESSION['id_client']);
$prenom    = $client['prenom']    ?? ''; 
$nom       = $client['nom']       ?? ''; 
$mail      = $client['mail']      ?? ''; 
$telephone = $client['telephone'] ?? '';

// Récupération du message de session (pour les notifications)
$session_msg = $_SESSION['message'] ?? '';
unset($_SESSION['message']);

// Récupération de la voiture sélectionnée si passée en paramètre
$id_voiture_select = $_GET['id'] ?? 0;


/// Recuperation heure d'ourverture su fermeture

$contact_contents = get_all_contenu_by_page($bdd, 'contact');
$lun_ven = find_contenu($contact_contents, 4);
$nombre = strlen($lun_ven['texte']);
$heure_base = [];

$heure_base[0] = $lun_ven['texte'][0].$lun_ven['texte'][1];
$heure_base[1] = 0 ;

for ($i = 0 ; $i < $nombre ; $i++) {
    if ($lun_ven['texte'][$i] == "-") {
        if ($lun_ven['texte'][$i+1] == " ") {
        $heure_base[1] = $lun_ven['texte'][$i+2].$lun_ven['texte'][$i+3];
        } else {
            $heure_base[1] = $lun_ven['texte'][$i+1].$lun_ven['texte'][$i+2];
        }
    }
    
}
?>

<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SuperCar - Demande d'essai</title>

    <!-- Bootstrap CSS -->
    <link href="assets/css/bootstrap.min.css" rel="stylesheet">
    <!-- Bootstrap Icons -->
    <link rel="stylesheet" href="assets/css/bootstrap-icons.css">

    <link rel="stylesheet" href="assets/css/demande-essai.css">
    <link rel="stylesheet" href="assets/css/notifications.css">
</head>


<body>

    <!-- Header Navigation -->
    <?php include('include/header.php'); ?>


    <!-- ─── HERO ─────────────────────────────────────────────────── -->
    <div class="container px-4">
        <div class="hero-section">
            <!-- Text -->
            <div class="hero-text">
                <h1 class="hero-title">Vivez l'expérience SUPERCAR</h1>
                <p class="hero-subtitle">Réservez votre essai et découvrez la puissance et<br>le luxe de nos véhicules
                    d'exception</p>
            </div>

            <!-- Car visual: Image -->
            <div class="hero-car-visual">
                <img src="assets/images/background/demande.jpg" alt="Demande d'essai" class="img-fluid rounded w-100"
                    style="object-fit: cover; max-height: 400px;">
            </div>
        </div>
    </div>


    <!-- ─── WHY SECTION ───────────────────────────────────────────── -->
    <section class="why-section">
        <div class="container px-4">
            <h2 class="section-title">Pourquoi faire un essai ?</h2>
            <div class="row g-3">

                <!-- Card 1 -->
                <div class="col-lg-4 col-md-6">
                    <div class="feature-card">
                        <div class="feature-icon-wrap">
                            <i class="bi bi-car-front-fill"></i>
                        </div>
                        <h5>Ressentez la puissance</h5>
                        <p>Rien ne remplace la sensation au volant. Découvrez les performances exceptionnelles de nos
                            véhicules.</p>
                    </div>
                </div>

                <!-- Card 2 -->
                <div class="col-lg-4 col-md-6">
                    <div class="feature-card">
                        <div class="feature-icon-wrap">
                            <i class="bi bi-check-circle-fill"></i>
                        </div>
                        <h5>Sans engagement</h5>
                        <p>Essayez nos véhicules en toute liberté, sans obligation d'achat. Prenez le temps de décider.
                        </p>
                    </div>
                </div>

                <!-- Card 3 -->
                <div class="col-lg-4 col-md-6">
                    <div class="feature-card">
                        <div class="feature-icon-wrap">
                            <i class="bi bi-clock-fill"></i>
                        </div>
                        <h5>Accompagnement expert</h5>
                        <p>Profitez des conseils de nos spécialistes passionnés pendant toute la durée de l'essai.</p>
                    </div>
                </div>

            </div>
        </div>
    </section>


    <!-- ─── FORM SECTION ──────────────────────────────────────────── -->
    <section class="form-section">
        <div class="container px-4">
            <div class="row justify-content-center">
                <div class="col-lg-8">
                    <div class="card border-0 shadow-sm rounded-4">
                        <div class="card-body p-4 p-md-5">
                            <h2 class="section-title text-center mb-2">Réservez votre essai</h2>
                            <p class="form-subtitle mb-4">Remplissez le formulaire ci-dessous et notre équipe vous
                                contactera rapidement</p>


                                


                        
                                <form id="essaiForm" action="backend/traitement-essaiPage.php" method="POST" novalidate>

                                <!-- Row 1: Prénom + Nom -->
                                <div class="row g-3 mb-3">
                                <div class="col-md-6">
                                    <label class="form-label">Prénom <span class="required">*</span></label>
                                    <input type="text" name="prenom" class="form-control" 
                                           value="<?= htmlspecialchars($prenom) ?>" required readonly>
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label">Nom <span class="required">*</span></label>
                                    <input type="text" name="nom" class="form-control" 
                                           value="<?= htmlspecialchars($nom) ?>" required readonly>
                                </div>
                            </div>

                                <!-- Row 2: Email + Téléphone -->
                                <div class="row g-3 mb-3">
                                <div class="col-md-6">
                                    <label class="form-label">Email <span class="required">*</span></label>
                                    <input type="email" name="email" class="form-control" 
                                           value="<?= htmlspecialchars($mail) ?>" required readonly>
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label">Téléphone <span class="required">*</span></label>
                                    <input type="tel" name="telephone" class="form-control" 
                                           value="<?= htmlspecialchars($telephone) ?>" required readonly>
                                </div>
                            </div>

                                <!-- Row 3: Date + Véhicule -->
                                <div class="row g-3 mb-3">
                                    <div class="col-md-6">
                                        <label class="form-label">Date préférée <span class="required">*</span></label>
                                        <input type="date" name="date_essai" class="form-control" 
                                            min="<?= date('Y-m-d', strtotime('+1 day')) ?>" required>
                                    </div>


                                    <!-- Heure de demande -->
                                    <div class="col-md-6">
                                        <label class="form-label">Heure de demande <span class="required">*</span></label>
                                        <select name="heure_essai" class="form-select" required>
                                            <option value="0">-- Choisissez une heure --</option>
                                            <?php for ($heure = $heure_base[0]; $heure <= $heure_base[1] - 1; $heure++) : ?>
                                                <option value="<?php echo $heure; ?>">
                                                    <?= sprintf('%02dh00', $heure) ?>
                                                </option>
                                            <?php endfor; ?>
                                        </select>
                                    </div>

                                </div>


                            <div class="col-md-12 mb-4">
                                    <label class="form-label">Véhicule</label>

                                    <?php 
                                            $result_voitures = getAllVoiture();

                                    ?>
                                    <select name="id_voiture" class="form-select" required>
                                        <option value="">-- Choisissez un véhicule --</option>
                                        
                                        <?php while ($voiture = mysqli_fetch_assoc($result_voitures)) : ?>
                                            <option value="<?= htmlspecialchars($voiture['idvoiture']) ?>" 
                                            <?= ((int)$id_voiture_select === (int)$voiture['idvoiture']) ? 'selected' : '' ?>>

                                               
                                                <?= htmlspecialchars($voiture['modele']) ?>
                                               
                                            </option>
                                        <?php endwhile; ?>
                                    </select>
                                </div>

                                <!-- Message -->
                                <!--<div class="mb-4">
                                    <label class="form-label">Message (optionnel)</label>
                                    <textarea class="form-control" rows="4"
                                        placeholder="Dites-nous en plus sur votre préférences ou toutes question particulière..."></textarea>
                                </div> -->

                                <!-- Buttons -->
                                <div class="row g-3">
                                    <div class="col-md-6">
                                        <button type="submit" class="btn btn-submit">Envoyer ma demande</button>
                                    </div>
                                    <div class="col-md-6">
                                        <button type="reset" class="btn btn-reset">Réinitialiser</button>
                                    </div>
                                </div>

                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>


    <!-- ─── FOOTER ────────────────────────────────────────────────── -->
    <!-- Footer -->
    <?php include('include/footer.html'); ?>


    <!-- Bootstrap JS -->
    <script src="assets/js/bootstrap.bundle.min.js"></script>
    <script src="assets/js/notifications.js"></script>
    <script src="assets/js/supercar.js"></script>
    <script>
        window.onload = function () {
            let sessionMessage = "<?php echo htmlspecialchars($session_msg); ?>";
            if (sessionMessage !== "") {
                showNotification(sessionMessage, "success");
            }
        }
    </script>
</body>


</html>
