-- Insertion des marques
INSERT INTO marques (nom_marque)
VALUES ('Mercedes'),
    ('Audi'),
    ('Porsche');
-- Insertion de voiture et de service est dans la base


-- Insertion du contenu pour la Section Hero (Ligne 1)
INSERT INTO contenu (lignecontenu, titre, texte, page)
VALUES (
        1,
        'Votre partenaire de confiance pour les voitures d''occasionss depuis 2009',
        'Consulter le catalogue',
        'accueil'
    );
-- Insertion du contenu pour la Section À propos
INSERT INTO contenu (lignecontenu, titre, texte, page)
VALUES (
        1,
        'À propos de SuperCar',
        'Depuis 2009, SuperCar est votre partenaire de confiance dans l\'acquisition de voitures d\'occasionss. Nous importons des véhicules de qualité supérieure en provenance des plus grands marchés automobiles mondiaux.',
        'apropos'
    ),
    (
        2,
        'Importation mondiale',
        'Véhicules d\'occasionss en provenance du Japon, Singapour, Afrique du Sud, États-Unis, Chine, Allemagne et France',
        'apropos'
    ),
    (
        3,
        '4 Entrepôts',
        'Nos 4 entrepôts stratégiquement placés nous permettent de stocker un large inventaire et d\'assurer des livraisons rapides.',
        'apropos'
    ),
    (
        4,
        'Siège Social',
        'Essayez tous nos modèles dans notre showroom principal',
        'apropos'
    );
-- Insertion du contenu pour la Section Processus
INSERT INTO contenu (lignecontenu, titre, texte, page)
VALUES (
        1,
        'Découverte',
        'Explorez notre catalogue et sélectionnez le modèle qui vous intéresse parmi notre large sélection de véhicules d''occasions importés.',
        'processus'
    ),
    (
        2,
        'Essai au Siège Social',
        'Testez une voiture d''essai de chaque modèle dans notre showroom. Nos conseillers vous accompagnent pour trouver le véhicule idéal.',
        'processus'
    ),
    (
        3,
        'Livraison',
        'Recevez un véhicule d''occasions identique, livré directement depuis nos entrepôts. Rapide, sécurisé et sans surprises.',
        'processus'
    );

-- Insertion du contenu pour la Section Contact
INSERT INTO contenu (lignecontenu, titre, texte, page)
VALUES (
        1,
        '0322 565 478',
        'Lun-Ven 08h-18h',
        'contact'
    ),
    (
        2,
        'supercar@gmail.com',
        'Réponse sous 24h',
        'contact'
    ),
    (
        3,
        'MCCI Business School, Ebene, Maurice',
        'Showroom principal',
        'contact'
    ),
    (
        4,
        'Lundi - Vendredi',
        '08h00 - 18h00',
        'contact'
    ),
    (
        5,
        'Samedi',
        '09h00 - 17h00',
        'contact'
    ),
    (
        6,
        'Dimanche',
        '10h00 - 15h00',
        'contact'
    ),
    (
        7,
        'MCCI Business School — Showroom principal SUPERCAR',
        'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d1198.5492211244302!2d57.48494871408381!3d-20.24355594411807!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x217c5b16955dcd29%3A0xe6719b48c3b7a89a!2sMCCI%20Business%20School!5e0!3m2!1sfr!2smu!4v1700000000000!5m2!1sfr!2smu',
        'contact'
    );


----- password  le mot de passe "Admin123#" ------
INSERT INTO admin (nom, prenom, mail, mot_de_passe)
VALUES (
    'RAZANADRAKOTO',
    'Fitahiana',
    'admin@supercar.com',
    '$2y$10$b5SKg60Mr.Yazgym68tEaue8Erg6hrdEAzfB1hS/X1FvDceILWK9.'
);